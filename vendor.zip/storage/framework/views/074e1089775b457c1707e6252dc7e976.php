

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if (isset($component)) { $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumb','data' => ['items' => [
        ['title' => 'Companies', 'url' => route('companies.index')]
    ]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
        ['title' => 'Companies', 'url' => route('companies.index')]
    ])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $attributes = $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $component = $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
    
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span><i class="bi bi-building"></i> Companies</span>
                    <div class="d-flex gap-2">
                        <a href="<?php echo e(route('companies.export', request()->query())); ?>" class="btn btn-success btn-sm no-print">
                            <i class="bi bi-file-earmark-spreadsheet"></i> Export CSV
                        </a>
                        <a href="<?php echo e(route('companies.create')); ?>" class="btn btn-primary btn-sm no-print">
                            <i class="bi bi-plus-circle"></i> Add New Company
                        </a>
                    </div>
                </div>

                <div class="card-body">
                    <!-- Search Bar -->
                    <div class="row mb-3 no-print">
                        <div class="col-md-12">
                            <form method="GET" action="<?php echo e(route('companies.index')); ?>" class="d-flex gap-2">
                                <div class="flex-grow-1">
                                    <input type="text" 
                                           name="search" 
                                           class="form-control" 
                                           placeholder="Search companies by name, email, or website..." 
                                           value="<?php echo e(request('search')); ?>">
                                </div>
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-search"></i> Search
                                </button>
                                <?php if(request('search')): ?>
                                    <a href="<?php echo e(route('companies.index')); ?>" class="btn btn-secondary">
                                        <i class="bi bi-x-circle"></i> Clear
                                    </a>
                                <?php endif; ?>
                            </form>
                        </div>
                    </div>

                    <?php if($companies->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-striped sortable-table">
                                <thead>
                                    <tr>
                                        <th>Logo</th>
                                        <th data-sort="name" class="<?php echo e(request('sort') == 'name' ? 'sort-' . request('direction', 'asc') : ''); ?>">
                                            Name
                                        </th>
                                        <th data-sort="email" class="<?php echo e(request('sort') == 'email' ? 'sort-' . request('direction', 'asc') : ''); ?>">
                                            Email
                                        </th>
                                        <th data-sort="website" class="<?php echo e(request('sort') == 'website' ? 'sort-' . request('direction', 'asc') : ''); ?>">
                                            Website
                                        </th>
                                        <th>Admin Access</th>
                                        <th width="200px" class="no-print">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php if($company->logo): ?>
                                                    <img src="<?php echo e(asset('storage/' . $company->logo)); ?>" alt="<?php echo e($company->name); ?>" style="width: 50px; height: 50px; object-fit: cover;" class="rounded-circle">
                                                <?php else: ?>
                                                    <div style="width: 50px; height: 50px;" 
                                                         class="bg-primary rounded-circle d-flex align-items-center justify-content-center text-white">
                                                        <strong><?php echo e(substr($company->name, 0, 1)); ?></strong>
                                                    </div>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($company->name); ?></td>
                                            <td><?php echo e($company->email ?? 'N/A'); ?></td>
                                            <td>
                                                <?php if($company->website): ?>
                                                    <a href="<?php echo e($company->website); ?>" target="_blank"><?php echo e(Str::limit($company->website, 30)); ?></a>
                                                <?php else: ?>
                                                    N/A
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($company->allow_admin): ?>
                                                    <span class="badge bg-success"><i class="bi bi-check-circle"></i> Enabled</span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary"><i class="bi bi-x-circle"></i> Disabled</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="no-print">
                                                <div class="d-flex gap-1 flex-wrap">
                                                    <a href="<?php echo e(route('companies.show', $company)); ?>" class="btn btn-info btn-sm" title="View">
                                                        <i class="bi bi-eye"></i>
                                                    </a>
                                                    <a href="<?php echo e(route('companies.edit', $company)); ?>" class="btn btn-warning btn-sm" title="Edit">
                                                        <i class="bi bi-pencil-square"></i>
                                                    </a>
                                                    
                                                    <form action="<?php echo e(route('companies.toggleAdmin', $company)); ?>" method="POST" class="d-inline">
                                                        <?php echo csrf_field(); ?>
                                                        <?php if($company->allow_admin): ?>
                                                            <button type="submit" class="btn btn-secondary btn-sm" 
                                                                    title="Disable Admin Access"
                                                                    onclick="return confirm('Disable admin access for <?php echo e($company->name); ?>? All admin employees will be demoted.')">
                                                                <i class="bi bi-shield-x"></i>
                                                            </button>
                                                        <?php else: ?>
                                                            <button type="submit" class="btn btn-success btn-sm" title="Enable Admin Access">
                                                                <i class="bi bi-shield-check"></i>
                                                            </button>
                                                        <?php endif; ?>
                                                    </form>
                                                    
                                                    <form action="<?php echo e(route('companies.destroy', $company)); ?>" method="POST" class="d-inline" id="delete-form-<?php echo e($company->id); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="button" class="btn btn-danger btn-sm" 
                                                                title="Delete"
                                                                onclick="if(confirm('Are you sure you want to delete <?php echo e(addslashes($company->name)); ?>? This action cannot be undone.')) { document.getElementById('delete-form-<?php echo e($company->id); ?>').submit(); }">
                                                            <i class="bi bi-trash"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                        <div class="d-flex justify-content-between align-items-center no-print">
                            <div class="text-muted">
                                Showing <?php echo e($companies->firstItem()); ?> to <?php echo e($companies->lastItem()); ?> of <?php echo e($companies->total()); ?> companies
                            </div>
                            <div>
                                <?php echo e($companies->links()); ?>

                            </div>
                        </div>
                    <?php else: ?>
                        <div class="empty-state">
                            <div class="empty-state-icon">
                                <i class="bi bi-building"></i>
                            </div>
                            <h3 class="empty-state-title">No Companies Found</h3>
                            <p class="empty-state-description">
                                <?php if(request('search')): ?>
                                    No companies match your search criteria. Try adjusting your search terms.
                                <?php else: ?>
                                    Get started by adding your first company to the system.
                                <?php endif; ?>
                            </p>
                            <?php if(request('search')): ?>
                                <a href="<?php echo e(route('companies.index')); ?>" class="btn btn-secondary">
                                    <i class="bi bi-x-circle"></i> Clear Search
                                </a>
                            <?php else: ?>
                                <a href="<?php echo e(route('companies.create')); ?>" class="btn btn-primary">
                                    <i class="bi bi-plus-circle"></i> Add Your First Company
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\mark\Documents\WebDesign\Laravel\resources\views/companies/index.blade.php ENDPATH**/ ?>