

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if (isset($component)) { $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumb','data' => ['items' => [
        ['title' => 'Employees', 'url' => route('employees.index')]
    ]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
        ['title' => 'Employees', 'url' => route('employees.index')]
    ])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $attributes = $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $component = $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
    
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span><i class="bi bi-people"></i> Employees</span>
                    <div class="d-flex gap-2">
                        <a href="<?php echo e(route('employees.export', request()->query())); ?>" class="btn btn-success btn-sm no-print">
                            <i class="bi bi-file-earmark-spreadsheet"></i> Export CSV
                        </a>
                        <a href="<?php echo e(route('employees.create')); ?>" class="btn btn-primary btn-sm no-print">
                            <i class="bi bi-plus-circle"></i> Add New Employee
                        </a>
                    </div>
                </div>

                <div class="card-body">
                    <!-- Search and Filter Bar -->
                    <div class="row mb-3 no-print">
                        <div class="col-md-8">
                            <form method="GET" action="<?php echo e(route('employees.index')); ?>" class="d-flex gap-2">
                                <div class="flex-grow-1">
                                    <input type="text" 
                                           name="search" 
                                           class="form-control" 
                                           placeholder="Search by name, email, phone, or company..." 
                                           value="<?php echo e(request('search')); ?>">
                                </div>
                                <input type="hidden" name="company_id" value="<?php echo e(request('company_id')); ?>">
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-search"></i> Search
                                </button>
                                <?php if(request('search') || request('company_id')): ?>
                                    <a href="<?php echo e(route('employees.index')); ?>" class="btn btn-secondary">
                                        <i class="bi bi-x-circle"></i> Clear
                                    </a>
                                <?php endif; ?>
                            </form>
                        </div>
                        <div class="col-md-4">
                            <form method="GET" action="<?php echo e(route('employees.index')); ?>">
                                <input type="hidden" name="search" value="<?php echo e(request('search')); ?>">
                                <select name="company_id" class="form-select" onchange="this.form.submit()">
                                    <option value="">All Companies</option>
                                    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($company->id); ?>" <?php echo e(request('company_id') == $company->id ? 'selected' : ''); ?>>
                                            <?php echo e($company->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </form>
                        </div>
                    </div>

                    <?php if($employees->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-striped sortable-table">
                                <thead>
                                    <tr>
                                        <th>Photo</th>
                                        <th data-sort="first_name" class="<?php echo e(request('sort') == 'first_name' ? 'sort-' . request('direction', 'asc') : ''); ?>">
                                            First Name
                                        </th>
                                        <th data-sort="last_name" class="<?php echo e(request('sort') == 'last_name' ? 'sort-' . request('direction', 'asc') : ''); ?>">
                                            Last Name
                                        </th>
                                        <th data-sort="company_id" class="<?php echo e(request('sort') == 'company_id' ? 'sort-' . request('direction', 'asc') : ''); ?>">
                                            Company
                                        </th>
                                        <th data-sort="email" class="<?php echo e(request('sort') == 'email' ? 'sort-' . request('direction', 'asc') : ''); ?>">
                                            Email
                                        </th>
                                        <th data-sort="phone" class="<?php echo e(request('sort') == 'phone' ? 'sort-' . request('direction', 'asc') : ''); ?>">
                                            Phone
                                        </th>
                                        <th width="200px" class="no-print">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php if($employee->profile_picture): ?>
                                                    <img src="<?php echo e(asset('storage/' . $employee->profile_picture)); ?>" 
                                                         alt="<?php echo e($employee->first_name); ?>" 
                                                         style="width: 50px; height: 50px; object-fit: cover;" 
                                                         class="rounded-circle">
                                                <?php elseif($employee->company && $employee->company->logo): ?>
                                                    <img src="<?php echo e(asset('storage/' . $employee->company->logo)); ?>" 
                                                         alt="<?php echo e($employee->company->name); ?>" 
                                                         style="width: 50px; height: 50px; object-fit: cover;" 
                                                         class="rounded-circle">
                                                <?php else: ?>
                                                    <div style="width: 50px; height: 50px;" 
                                                         class="bg-secondary rounded-circle d-flex align-items-center justify-content-center text-white">
                                                        <strong><?php echo e(substr($employee->first_name, 0, 1)); ?><?php echo e(substr($employee->last_name, 0, 1)); ?></strong>
                                                    </div>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($employee->first_name); ?></td>
                                            <td>
                                                <?php echo e($employee->last_name); ?>

                                                <?php if($employee->user_id): ?>
                                                    <span class="badge bg-success ms-1"><i class="bi bi-shield-check"></i> Admin</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($employee->company): ?>
                                                    <a href="<?php echo e(route('companies.show', $employee->company)); ?>"><?php echo e($employee->company->name); ?></a>
                                                    <?php if($employee->company->allow_admin): ?>
                                                        <span class="badge bg-success ms-1" title="Admin access enabled">
                                                            <i class="bi bi-shield-check"></i>
                                                        </span>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <span class="text-muted">No Company</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($employee->email ?? 'N/A'); ?></td>
                                            <td><?php echo e($employee->phone ?? 'N/A'); ?></td>
                                            <td class="no-print">
                                                <div class="d-flex gap-1 flex-wrap">
                                                    <a href="<?php echo e(route('employees.show', $employee)); ?>" class="btn btn-info btn-sm" title="View Employee">
                                                        <i class="bi bi-eye"></i>
                                                    </a>
                                                    <a href="<?php echo e(route('employees.edit', $employee)); ?>" class="btn btn-warning btn-sm" title="Edit Employee">
                                                        <i class="bi bi-pencil-square"></i>
                                                    </a>
                                                    <form action="<?php echo e(route('employees.destroy', $employee)); ?>" method="POST" class="d-inline" id="delete-form-<?php echo e($employee->id); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="button" class="btn btn-danger btn-sm" title="Delete Employee" 
                                                                onclick="if(confirm('Are you sure you want to delete <?php echo e(addslashes($employee->first_name . ' ' . $employee->last_name)); ?>? This action cannot be undone.')) { document.getElementById('delete-form-<?php echo e($employee->id); ?>').submit(); }">
                                                            <i class="bi bi-trash"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                        <div class="d-flex justify-content-between align-items-center no-print">
                            <div class="text-muted">
                                Showing <?php echo e($employees->firstItem()); ?> to <?php echo e($employees->lastItem()); ?> of <?php echo e($employees->total()); ?> employees
                            </div>
                            <div>
                                <?php echo e($employees->links()); ?>

                            </div>
                        </div>
                    <?php else: ?>
                        <div class="empty-state">
                            <div class="empty-state-icon">
                                <i class="bi bi-people"></i>
                            </div>
                            <h3 class="empty-state-title">No Employees Found</h3>
                            <p class="empty-state-description">
                                <?php if(request('search') || request('company_id')): ?>
                                    No employees match your search criteria. Try adjusting your filters.
                                <?php else: ?>
                                    Get started by adding your first employee to the system.
                                <?php endif; ?>
                            </p>
                            <?php if(request('search') || request('company_id')): ?>
                                <a href="<?php echo e(route('employees.index')); ?>" class="btn btn-secondary">
                                    <i class="bi bi-x-circle"></i> Clear Filters
                                </a>
                            <?php else: ?>
                                <a href="<?php echo e(route('employees.create')); ?>" class="btn btn-primary">
                                    <i class="bi bi-plus-circle"></i> Add Your First Employee
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\mark\Documents\WebDesign\Laravel\resources\views/employees/index.blade.php ENDPATH**/ ?>