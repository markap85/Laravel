

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="mb-0">Welcome, <?php echo e(Auth::user()->name); ?>!</h4>
                </div>

                <div class="card-body">
                    <!-- Statistics Cards -->
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <div class="card bg-primary text-white shadow-dark">
                                <div class="card-body text-center">
                                    <h2 class="display-4 text-white"><?php echo e($totalCompanies); ?></h2>
                                    <p class="mb-3">Total Companies</p>
                                    <a href="<?php echo e(route('companies.create')); ?>" class="btn btn-light btn-sm">
                                        <i class="bi bi-plus-circle"></i> Add Company
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card bg-success text-white shadow-dark">
                                <div class="card-body text-center">
                                    <h2 class="display-4 text-white"><?php echo e($totalEmployees); ?></h2>
                                    <p class="mb-3">Total Employees</p>
                                    <a href="<?php echo e(route('employees.create')); ?>" class="btn btn-light btn-sm">
                                        <i class="bi bi-plus-circle"></i> Add Employee
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Recent Lists -->
                    <div class="row">
                        <!-- Recent Companies -->
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header d-flex justify-content-between align-items-center">
                                    <strong>Recent Companies</strong>
                                    <a href="<?php echo e(route('companies.index')); ?>" class="btn btn-sm btn-outline-primary">View All</a>
                                </div>
                                <div class="card-body p-0">
                                    <?php if($recentCompanies->count() > 0): ?>
                                        <ul class="list-group list-group-flush">
                                            <?php $__currentLoopData = $recentCompanies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="list-group-item">
                                                    <div class="d-flex align-items-center">
                                                        <div class="me-3">
                                                            <?php if($company->logo): ?>
                                                                <img src="<?php echo e(asset('storage/' . $company->logo)); ?>" 
                                                                     alt="<?php echo e($company->name); ?>" 
                                                                     style="width: 50px; height: 50px; object-fit: cover;"
                                                                     class="rounded-circle">
                                                            <?php else: ?>
                                                                <div style="width: 50px; height: 50px;" 
                                                                     class="bg-secondary rounded-circle d-flex align-items-center justify-content-center text-white">
                                                                    <strong><?php echo e(substr($company->name, 0, 1)); ?></strong>
                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="flex-grow-1">
                                                            <a href="<?php echo e(route('companies.show', $company)); ?>" class="text-decoration-none">
                                                                <strong><?php echo e($company->name); ?></strong>
                                                            </a>
                                                            <br>
                                                            <small class="text-muted">
                                                                Created <?php echo e($company->created_at->diffForHumans()); ?>

                                                            </small>
                                                        </div>
                                                    </div>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    <?php else: ?>
                                        <p class="text-muted p-3">No companies yet. <a href="<?php echo e(route('companies.create')); ?>">Create one now</a></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <!-- Recent Employees -->
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header d-flex justify-content-between align-items-center">
                                    <strong>Recent Employees</strong>
                                    <a href="<?php echo e(route('employees.index')); ?>" class="btn btn-sm btn-outline-success">View All</a>
                                </div>
                                <div class="card-body p-0">
                                    <?php if($recentEmployees->count() > 0): ?>
                                        <ul class="list-group list-group-flush">
                                            <?php $__currentLoopData = $recentEmployees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="list-group-item">
                                                    <div class="d-flex align-items-center">
                                                        <div class="me-3">
                                                            <?php if($employee->profile_picture): ?>
                                                                <img src="<?php echo e(asset('storage/' . $employee->profile_picture)); ?>" 
                                                                     alt="<?php echo e($employee->first_name); ?>" 
                                                                     style="width: 50px; height: 50px; object-fit: cover;"
                                                                     class="rounded-circle">
                                                            <?php elseif($employee->company && $employee->company->logo): ?>
                                                                <img src="<?php echo e(asset('storage/' . $employee->company->logo)); ?>" 
                                                                     alt="<?php echo e($employee->company->name); ?>" 
                                                                     style="width: 50px; height: 50px; object-fit: cover;"
                                                                     class="rounded-circle">
                                                            <?php else: ?>
                                                                <div style="width: 50px; height: 50px;" 
                                                                     class="bg-info rounded-circle d-flex align-items-center justify-content-center text-white">
                                                                    <strong><?php echo e(substr($employee->first_name, 0, 1)); ?><?php echo e(substr($employee->last_name, 0, 1)); ?></strong>
                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="flex-grow-1">
                                                            <a href="<?php echo e(route('employees.show', $employee)); ?>" class="text-decoration-none">
                                                                <strong><?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?></strong>
                                                            </a>
                                                            <?php if($employee->company): ?>
                                                                <br>
                                                                <small class="text-muted"><?php echo e($employee->company->name); ?></small>
                                                            <?php endif; ?>
                                                            <br>
                                                            <small class="text-muted">
                                                                Created <?php echo e($employee->created_at->diffForHumans()); ?>

                                                            </small>
                                                        </div>
                                                    </div>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    <?php else: ?>
                                        <p class="text-muted p-3">No employees yet. <a href="<?php echo e(route('employees.create')); ?>">Create one now</a></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\mark\Documents\WebDesign\Laravel\resources\views/dashboard.blade.php ENDPATH**/ ?>