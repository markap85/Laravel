<nav aria-label="breadcrumb" class="no-print">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><i class="bi bi-house-door"></i> Dashboard</a></li>
        <?php if(isset($items)): ?>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($loop->last): ?>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($item['title']); ?></li>
                <?php else: ?>
                    <li class="breadcrumb-item"><a href="<?php echo e($item['url']); ?>"><?php echo e($item['title']); ?></a></li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </ol>
</nav>
<?php /**PATH C:\Users\mark\Documents\WebDesign\Laravel\resources\views/components/breadcrumb.blade.php ENDPATH**/ ?>